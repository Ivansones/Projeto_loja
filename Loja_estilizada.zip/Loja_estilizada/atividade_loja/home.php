<?php
$connect = mysql_connect('localhost','root','');
$db = mysql_select_db('loja');
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="Estilo.css">
</head>
<body>
<form name="formulario" method="post" action="home.php">
    <div id="legal">
    <div id="titulo">
    <h1>Material Esportivo</h1><br>
    </div>
    </div>
    <br><br>
    <h1>Pesquisas:</h1>
    <label for="">Categoria</label>
    <select name="categoria" >
        <option value="" selected="selected">selecione</option>

        <?php
        $query = mysql_query("select codigo,nome from categoria");
        while($categorias=mysql_fetch_array($query)) { ?>
        <option value="<?php echo $categorias['codigo']?>"><?php echo $categorias['nome'] ?></option>
        <?php } ?>
    </select>

    <label for="">marca</label>
    <select name="marca" >
        <option value="" selected="selected">selecione</option>

        <?php
        $query = mysql_query("select codigo,nome from marca");
        while($marcas=mysql_fetch_array($query)) { ?>
        <option value="<?php echo $marcas['codigo']?>"><?php echo $marcas['nome'] ?></option>
        <?php } ?>
    </select>

    <label for="">tipo</label>
    <select name="tipo" >
        <option value="" selected="selected">selecione</option>

        <?php
        $query = mysql_query("select codigo,nome from tipo");
        while($tipos=mysql_fetch_array($query)) { ?>
        <option value="<?php echo $tipos['codigo']?>"><?php echo $tipos['nome'] ?></option>
        <?php } ?>
    </select>

    <input type="submit" name="pesquisar" value="Pesquisar">
</form>
<br><br>
<?php
if (isset($_POST['pesquisar'])) {
    $marca = (empty($_POST['marca'])) ? 'null' : $_POST['marca'];
    $categoria = (empty($_POST['categoria'])) ? 'null' : $_POST['categoria'];
    $tipo = (empty($_POST['tipo'])) ? 'null' : $_POST['tipo'];

    if (($marca <> 'null') and ($categoria == 'null') and ($tipo == 'null')) {
        $sql_produto = "select produto.descricao, produto.cor, produto.tamanho, produto.preco, produto.foto1, produto.foto2 
                        from produto, marca, tipo, categoria
                        where produto.codmarca = marca.codigo
                        and produto.codcategoria = categoria.codigo
                        and produto.codtipo = tipo.codigo
                        and marca.codigo = $marca";

        $seleciona_produtos = mysql_query($sql_produto);
    }

    else if (($marca <> 'null') and ($categoria <> 'null') and ($tipo == 'null')) {
        $sql_produto = "select produto.descricao, produto.cor, produto.tamanho, produto.preco, produto.foto1, produto.foto2 
                        from produto, marca, tipo, categoria
                        where produto.codmarca = marca.codigo
                        and produto.codcategoria = categoria.codigo
                        and produto.codtipo = tipo.codigo
                        and marca.codigo = $marca
                        and categoria.codigo = $categoria";

        $seleciona_produtos = mysql_query($sql_produto);
    }

    else if (($marca <> 'null') and ($categoria <> 'null') and ($tipo <> 'null')) {
        $sql_produto = "select produto.descricao, produto.cor, produto.tamanho, produto.preco, produto.foto1, produto.foto2 
                        from produto, marca, tipo, categoria
                        where produto.codmarca = marca.codigo
                        and produto.codcategoria = categoria.codigo
                        and produto.codtipo = tipo.codigo
                        and marca.codigo = $marca
                        and categoria.codigo = $categoria
                        and tipo.codigo = $tipo";

        $seleciona_produtos = mysql_query($sql_produto);
    }

    else if (($marca <> 'null') and ($categoria == 'null') and ($tipo <> 'null')) {
        $sql_produto = "select produto.descricao, produto.cor, produto.tamanho, produto.preco, produto.foto1, produto.foto2 
                        from produto, marca, tipo, categoria
                        where produto.codmarca = marca.codigo
                        and produto.codcategoria = categoria.codigo
                        and produto.codtipo = tipo.codigo
                        and marca.codigo = $marca
                        and tipo.codigo = $tipo";

        $seleciona_produtos = mysql_query($sql_produto);
    }

    else if (($marca == 'null') and ($categoria == 'null') and ($tipo <> 'null')) {
        $sql_produto = "select produto.descricao, produto.cor, produto.tamanho, produto.preco, produto.foto1, produto.foto2 
                        from produto, marca, tipo, categoria
                        where produto.codmarca = marca.codigo
                        and produto.codcategoria = categoria.codigo
                        and produto.codtipo = tipo.codigo
                        and tipo.codigo = $tipo";

        $seleciona_produtos = mysql_query($sql_produto);
    }

    else if (($marca == 'null') and ($categoria <> 'null') and ($tipo <> 'null')) {
        $sql_produto = "select produto.descricao, produto.cor, produto.tamanho, produto.preco, produto.foto1, produto.foto2 
                        from produto, marca, tipo, categoria
                        where produto.codmarca = marca.codigo
                        and produto.codcategoria = categoria.codigo
                        and produto.codtipo = tipo.codigo
                        and categoria.codigo = $categoria
                        and tipo.codigo = $tipo";

        $seleciona_produtos = mysql_query($sql_produto);
    }

    else if (($marca == 'null') and ($categoria <> 'null') and ($tipo == 'null')) {
        $sql_produto = "select produto.descricao, produto.cor, produto.tamanho, produto.preco, produto.foto1, produto.foto2 
                        from produto, marca, tipo, categoria
                        where produto.codmarca = marca.codigo
                        and produto.codcategoria = categoria.codigo
                        and produto.codtipo = tipo.codigo
                        and categoria.codigo = $categoria";

        $seleciona_produtos = mysql_query($sql_produto);
    }

    else if (($marca == 'null') and ($categoria == 'null') and ($tipo == 'null')) {
        $sql_produto = "select produto.descricao, produto.cor, produto.tamanho, produto.preco, produto.foto1, produto.foto2 
                        from produto, marca, tipo, categoria
                        where produto.codmarca = marca.codigo
                        and produto.codcategoria = categoria.codigo
                        and produto.codtipo = tipo.codigo";

        $seleciona_produtos = mysql_query($sql_produto);
    }

    if (mysql_num_rows($seleciona_produtos) == 0) {
        echo "<div class='results'><h2>A sua pesquisa não trouxe resultados</h2></div>";
    } else {
        echo "<div class='results'><h2>Resultados da pesquisa dos produtos:</h2><br>";
        while ($dados = mysql_fetch_object($seleciona_produtos)) {
            echo 
                 "descricao: " . $dados->descricao . "<br>" .
                 "cor: " . $dados->cor . "<br>" .
                 "tamanho: " . $dados->tamanho . "<br>" .
                 "preco: " . $dados->preco . "<br>" .
                 '<img src="imagens/' . $dados->foto1 . '" height="100" width="150" /><br><br>' .
                 '<img src="imagens/' . $dados->foto2 . '" height="100" width="150" /><br><br>';
        }
        echo "</div>";
    }
}

?>
</body>
</html>
